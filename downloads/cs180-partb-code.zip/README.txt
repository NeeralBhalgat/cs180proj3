Neeral Bhalgat - CS180 Project 3 Part B
The notebook includes saved outputs. Run on a GPU in Colab. Training uses MNIST.
