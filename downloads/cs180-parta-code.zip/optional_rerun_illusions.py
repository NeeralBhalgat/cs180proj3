# Optional Colab cell: run AFTER setup and your completed function definitions.
# Saves candidates separately. Does not replace your existing selected results.
from pathlib import Path
import json
candidate_dir = OUT / 'illusion_candidates'
candidate_dir.mkdir(exist_ok=True)
jobs = [
    ('anagram', "an oil painting of a bearded wizard's face",
     'an oil painting of a mountain castle above a river'),
    ('hybrid', "a lithograph of a lion's face",
     'a lithograph of a field of sunflowers'),
]
# Start with two extra seeds to limit GPU work; expand only if needed.
for kind, a, b in jobs:
    ca, cb = model.encode(a), model.encode(b)
    for seed in [182, 183]:
        fn = visual_anagrams if kind == 'anagram' else make_hybrids
        x = fn(noise(seed), ca, cb, predict_velocity, w=7, step_size=0.02)
        stem = f'{kind}_seed_{seed}'
        to_pil(x).save(candidate_dir / f'{stem}.png')
        (candidate_dir / f'{stem}.json').write_text(json.dumps(
            {'kind': kind, 'seed': seed, 'prompt_a': a, 'prompt_b': b,
             'cfg_w': 7, 'step_size': 0.02}, indent=2))
        print(kind, seed, '\nA:', a, '\nB:', b)
        display(to_pil(x))
        if kind == 'anagram':
            display(to_pil(rotate180(x)))
        else:
            display(to_pil(x).resize((64, 64), Image.Resampling.LANCZOS))
print('Review both views before selecting replacements:', candidate_dir)
