CS180 Project 3 Part A - Neeral Bhalgat

parta.ipynb contains the exact supplied notebook source with saved outputs removed for size. The original notebook with outputs remains in Downloads. No implementation code was changed.

Run in a GPU Colab runtime. Upload the Luke scene, portrait, Yoda, house drawing, and tree drawing, and update the input paths before running the input cells. The setup cell includes the course support code.

The optional rerun cell saves separate candidates for the two weaker illusions; it does not replace any selected output.

See AUDIT.md for the deliverable review and remaining quality/attribution questions.
