# Part A audit - Neeral Bhalgat

Reviewed the latest notebook and the single run in parta_results.zip against the official Part A webpage on October 17, 2026 (America/Los_Angeles). All required result sets exist. This is a deliverable audit, not a guarantee of a grade.

| Section | Evidence | Status |
|---|---|---|
| 1.1 | training_inputs.png; notebook cells 5 and 9 | Original plus three times, shared noise, correct interpolation |
| 1.2 | blur_0.25/0.5/0.75.png; cell 11 | Correct x/t amplitude correction; sigma selected from five candidates |
| 1.3 | one_step_*.png; cells 5 and 13 | Correct velocity extrapolation; all three triplets |
| 1.4 | velocity_original and three velocity panels; cells 15-16 | Correct RGB RMS before scaling; common signed and error limits |
| 1.5 | trajectory, comparison, metrics.json; cells 5 and 18 | Six labeled states, 25 updates, same-input comparison |
| 1.6 | conditional_0 through 4; cell 20 | Five samples, seeds 180-184 |
| 2.1 | cfg_0 through 4; cells 5 and 23 | Same seeds, correct vc + 7(vc-vu), empty embedding |
| 3.1 | Six edit panels; cells 26 and 28 | Campanile, Luke, portrait, web Yoda, house, tree; original plus all seven times |
| 3.2 | Three text_edit panels; cell 30 | All three prompts and all seven times, including portrait |
| 3.3 | Two anagrams; cells 5 and 32 | Correct rotation/velocity averaging; wizard/castle quality risk |
| 3.4 | Two hybrids; cells 5 and 34 | Correct frequency split; kernel 265/sigma 16; lion/sunflowers quality risk |

## Remaining work to reduce grading risk

1. Rerun the wizard/castle anagram with a few seeds and select a pair with two clearly recognizable orientations. The lion/forest pair is stronger.
2. Rerun the lion/sunflowers hybrid; its distant lion is ambiguous. The turtle/city is more recognizable but could also be improved. Use the supplied optional rerun cell; inspect actual outputs before replacing anything.
3. Add source URLs for the Luke film still and Yoda web image. The site already contains the needed image content; no replacement input is needed for display.
4. Confirm that the house and tree images are drawings you made, as required by the assignment. Their image files alone cannot establish authorship.
5. For reproducibility, the notebook uses Colab-specific input paths. Upload the original Luke and childhood-portrait files if rerunning from a fresh runtime; they are not included as standalone originals in the ZIP. House/tree/Yoda originals are present in the workspace. Display panels do include all originals.
6. Submit the website PDF and notebook/code to the corresponding Gradescope assignments. Part B and the final gallery form remain for later. CS280A extras are not required for CS180.

## Validation and limits

- No saved notebook error outputs found. Source inspection matches the assignment equations.
- metrics.json records Euler full/half/shortened-step checks, zero-weight CFG check, and rotation involution check as passed.
- Local Torch execution could not start because the user's installed NumPy binary has an incompatible architecture. No GPU model rerun was performed. This does not invalidate the recorded Colab outputs, but they are the execution evidence.
- Saved MSE: blur 0.004861942958086729; one-step 0.0013923271326348186; Euler 0.0019518069457262754. The website accurately reports one-step as best on this metric.
- ZIP contains only one run: 20261018-010546-36d461. No competing runs or duplicate result sets needed selection.
- Reference portfolio loads in the in-app browser despite direct HTTP fetches returning 404.

Official requirements: https://cal-cs180.github.io/fa26/hw/proj3-flow/parta.html
